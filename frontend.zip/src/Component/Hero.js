import React from 'react';
import Carousel from 'react-bootstrap/Carousel';
import './AppHero.css'; // Import du fichier CSS

const heroData = [
  {
    id: 1,
    image: require('../assets/images/chatbot.png'),
    title: 'Chatbot Médical',
    description: 'Chatbot médical intelligent, conçu pour assister les utilisateurs dans la gestion de leurs questions liées à la santé. Développé avec Rasa, une plateforme open-source avancée pour la création de chatbots, ce chatbot combine des capacités de traitement du langage naturel (NLP) avec des fonctionnalités d’intelligence artificielle. Il vise à fournir des réponses rapides, précises et personnalisées sur des sujets médicaux courants.',
  },
  {
    id: 2,
    image: require('../assets/images/skin.png'),
    title: 'Prédiction du cancer de la peau',
    description: 'Modèles de prédiction basés sur les réseaux neuronaux pour le diagnostic automatisé des lésions cutanées pigmentées, répondant aux défis de diversité et de taille des ensembles de données.',
  },
];

function AppHero() {
  return (
    <section id="home" className="hero-block">
      <Carousel>
        {heroData.map((hero) => (
          <Carousel.Item key={hero.id}>
            <div className="carousel-image-wrapper">
              <img
                className="carousel-image"
                src={hero.image}
                alt={`slide ${hero.id}`}
              />
            </div>
            <Carousel.Caption>
              <h2>{hero.title}</h2>
              <p>{hero.description}</p>
              <a className="btn btn-primary" href={hero.link}>
                En savoir plus <i className="fas fa-chevron-right"></i>
              </a>
            </Carousel.Caption>
          </Carousel.Item>
        ))}
      </Carousel>
    </section>
  );
}

export default AppHero;
