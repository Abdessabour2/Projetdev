import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Image } from 'react-bootstrap';
import './AppAbout.css'
export default function AppAbout() {
  const [teamData, setTeamData] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8000/api/about/') // API URL for fetching team data
      .then(response => response.json())
      .then(data => {
        setTeamData(data);
      })
      .catch(error => {
        console.error('Error fetching team data:', error);
      });
  }, []); // Empty array to run once on component mount

  return (
    <section id='team' className='block team-block'>
      <Container fluid>
        <div className='title-holder'>
          <h2>Our Team</h2>
          <div className='subtitle'>Meet Our Experts</div>
        </div>
        <Row>
          {teamData.map((team) => (
            <Col sm={4} key={team.id} className="team-member">
              <div className='image'>
                <Image
                  src={`http://localhost:8000${team.image}`}
                  alt={team.name}
                  fluid
                  className="team-image"
                />
                <div className='overlay'>
                  <div className='socials'>
                    <ul>
                      {team.linkedLink && (
                        <li>
                          <a href={team.linkedLink} target="_blank" rel="noreferrer">
                            <i className="bi bi-linkedin"></i>
                          </a>
                        </li>
                      )}
                      {team.githubLink && (
                        <li>
                          <a href={team.githubLink} target="_blank" rel="noreferrer">
                            <i className="bi bi-github"></i>
                          </a>
                        </li>
                      )}
                      {team.fbLink && (
                        <li>
                          <a href={team.fbLink} target="_blank" rel="noreferrer">
                            <i className="bi bi-facebook"></i>
                          </a>
                        </li>
                      )}
                    </ul>
                  </div>
                </div>
              </div>
              <div className='content'>
                <h3>{team.name}</h3>
                <span className='designation'>{team.designation}</span>
                <p>{team.description}</p>
              </div>
            </Col>
          ))}
        </Row>
      </Container>
    </section>
  );
}
