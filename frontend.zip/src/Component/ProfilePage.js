import React, { useEffect, useState } from 'react';
import { getAccessToken } from './auth'; 

function ProfilePage() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [imagePreview, setImagePreview] = useState(null); 

  useEffect(() => {
    const fetchProfile = async () => {
      const token = await getAccessToken();
      console.log(token);
      const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
      };

      const response = await fetch('http://localhost:8000/api/profile/', {
        method: 'GET',
        headers: headers,
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Profile data received:', data);
        setProfile(data);
        setLoading(false);
        if (data.profile_picture) {
            setImagePreview(data.profile_picture); // Prévisualiser l'image
        }
      } else {
        console.error('Erreur lors de la récupération du profil:', response.status);
      }
    };

    fetchProfile();
  }, []);

  // Fonction pour gérer l'upload de l'image
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Fonction pour soumettre le formulaire de modification du profil
  const handleSubmit = async (e) => {
    e.preventDefault();

    const token = await getAccessToken();
    const formData = new FormData();
    formData.append('username', profile.username);
    formData.append('email', profile.email);
    formData.append('phone_number', profile.phone_number);
    formData.append('address', profile.address);

    if (profile.profile_picture) {
      formData.append('profile_picture', profile.profile_picture); // Ajouter la photo de profil si présente
    }
    for (let pair of formData.entries()) {
        console.log(pair[0]+ ': ' + pair[1]);
      }

    const response = await fetch('http://localhost:8000/api/profile/', {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
      body: formData,
    });

    if (response.ok) {
      const data = await response.json();
      console.log(data);
      setProfile(data);
    } else {
      console.error('Erreur lors de la mise à jour du profil:', response.status);
    }
  };

  if (loading) return <div>Loading...</div>;
  if (!profile) return <div>Failed to load profile</div>;

  return (
    <div>
      <h2>Edit Your Profile</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username</label>
          <input
            type="text"
            value={profile.username}
            onChange={(e) => setProfile({ ...profile, username: e.target.value })}
          />
        </div>

        <div>
          <label>Email</label>
          <input
            type="email"
            value={profile.email}
            onChange={(e) => setProfile({ ...profile, email: e.target.value })}
          />
        </div>

        <div>
          <label>Phone</label>
          <input
            type="text"
            value={profile.phone_number}
            onChange={(e) => setProfile({ ...profile, phone_number: e.target.value })}
          />
        </div>

        <div>
          <label>Address</label>
          <input
            type="text"
            value={profile.address}
            onChange={(e) => setProfile({ ...profile, address: e.target.value })}
          />
        </div>

        <div>
          <label>Profile Picture</label>
          <input type="file" onChange={handleImageChange} />
          {imagePreview && <img src={imagePreview} alt="Profile Preview" />}
        </div>

        <button type="submit">Save Changes</button>
      </form>
    </div>
  );
}

export default ProfilePage;
