import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Image from 'react-bootstrap/Image'

const teamsData=[
    {
        id:1 ,
        image:require('../assets/images/houdayfa.png'),
        linkedLink:'https://www.linkedin.com/in/houdayfa-housny-794a58285/',
        githubLink:'https://github.com/Houdayfahousny',
        fbLink:'https://www.facebook.com/profile.php?id=100008389418691',
        name:'Houdayfa HOUSNY',
        designation:'frontend & backend cell ',
        description:'I created an intuitive interface to facilitate user interaction and I focused on integrating machine learning models'

    },
    {
        id:2 ,
        image:require('../assets/images/abdessabour.png'),
        linkedLink:'https://www.linkedin.com/in/abdessabour-ahzab-9734082a5/?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
        githubLink:'https://github.com/Abdessabour2',
        fbLink:'https://www.facebook.com/abdessabour.ahzab.39',
        name:'Abdessabour AHZAB',
        designation:'chef de projet',
        description:'as a project manager I involved on overseeing the planning, organization, and execution of a project to ensure it is completed on time '

    },
    {
        id:3 ,
        image:require('../assets/images/Ramzi.png'),
        linkedLink:'',
        githubLink:'',
        fbLink:'',
        name:'Youssef RAMZI',
        designation:'Data cell',
        description:'as a Data cell member , I worked on develop the model for predicting the type of cancer '

    }
]

export default function AppTeam(){
    return(
        <section id='team' className='block team-block'>
           <Container fluid>
                <div className='title-holder'>
                    <h2>Our team</h2>
                    <div className='subtitle'>our experts</div>
                </div>
             <Row >
                {
                    teamsData.map(teams =>{
                        return(
                            <Col sm={4} Key={teams.id}>
                                <div className='image'>
                                   <Image src={teams.image} alt="no image"/>
                                    <div className='overlay'>
                                        <div className='socials'>
                                            <ul>
                                                <li><a href={teams.linkedLink}><i class="bi bi-linkedin"></i></a></li>
                                                <li><a href={teams.githubLink}><i class="bi bi-github"></i></a></li>
                                                <li><a href={teams.fbLink}><i class="bi bi-facebook"></i></a></li>
                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className='content'>
                                    <h3>{teams.name}</h3>
                                    <span className='designation'>{teams.designation}</span>
                                    <p>{teams.description}</p>
                                 </div>
                            </Col>

                        )
                    })
                }
                
            </Row>
           </Container>
        </section>
    )
}