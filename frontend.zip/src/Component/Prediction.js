import React, { useState } from "react";

function Prediction() {
  const [image, setImage] = useState(null); // Stocke l'image téléchargée
  const [result, setResult] = useState(""); // Résultat de la prédiction
  const [info, setInfo] = useState(""); // Explications associées
  const [loading, setLoading] = useState(false); // Indicateur de chargement
  const [error, setError] = useState(""); // Message d'erreur éventuel

  // Gestion de l'image téléchargée
  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
    setError(""); // Réinitialise les erreurs précédentes
  };

  // Envoi de l'image au backend
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!image) {
      setError("Veuillez télécharger une image avant de soumettre.");
      return;
    }

    setLoading(true); // Commence l'indicateur de chargement
    setError(""); // Réinitialise les erreurs précédentes
    setResult(""); // Réinitialise le résultat précédent
    setInfo(""); // Réinitialise l'info précédente

    const formData = new FormData();
    formData.append("image", image);

    try {
      const response = await fetch("http://127.0.0.1:8000/predict/", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        
        const data = await response.json();
        console.error(data);
        setResult(data.prediction);

        setInfo(data.info);
      } else {
        const errorData = await response.json();
        setError(errorData.error || "La prédiction a échoué.");
      }
    } catch (err) {
      setError("Erreur lors de l'envoi de la requête. Veuillez réessayer.");
      console.error(err);
    } finally {
      setLoading(false); // Fin du chargement
    }
  };

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      <h1 style={{ textAlign: "center", color: "#4CAF50" }}>
        Prédiction de Lésions Cutanées
      </h1>

      <form
        onSubmit={handleSubmit}
        style={{
          maxWidth: "500px",
          margin: "0 auto",
          padding: "20px",
          border: "1px solid #ccc",
          borderRadius: "10px",
          backgroundColor: "#f9f9f9",
        }}
      >
        <div style={{ marginBottom: "15px" }}>
          <label
            htmlFor="image"
            style={{
              display: "block",
              fontWeight: "bold",
              marginBottom: "10px",
            }}
          >
            Téléchargez une image :
          </label>
          <input
            type="file"
            id="image"
            accept="image/*"
            onChange={handleImageChange}
            style={{
              width: "100%",
              padding: "10px",
              border: "1px solid #ccc",
              borderRadius: "5px",
            }}
          />
        </div>

        {error && (
          <p style={{ color: "red", marginBottom: "15px" }}>{error}</p>
        )}

        <button
          type="submit"
          style={{
            display: "block",
            width: "100%",
            padding: "10px",
            backgroundColor: "#4CAF50",
            color: "white",
            border: "none",
            borderRadius: "5px",
            fontWeight: "bold",
            cursor: "pointer",
          }}
        >
          {loading ? "Prédiction en cours..." : "Prédire"}
        </button>
      </form>

      {result && (
        <div
          style={{
            maxWidth: "500px",
            margin: "20px auto",
            padding: "20px",
            border: "1px solid #4CAF50",
            borderRadius: "10px",
            backgroundColor: "#e8f5e9",
          }}
        >
          <h3 style={{ color: "#4CAF50" }}>Résultat : {result}</h3>
          <p>{info}</p>
        </div>
      )}
    </div>
  );
}

export default Prediction;
