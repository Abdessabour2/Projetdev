// src/utils/auth.js

// Fonction pour obtenir un nouveau jeton d'accès en utilisant un jeton de rafraîchissement
export const getNewAccessToken = async () => {
    const refreshToken = localStorage.getItem('refresh_token');  // Récupérer le jeton de rafraîchissement
  
    if (!refreshToken) {
      console.error("Le jeton de rafraîchissement est manquant.");
      return null;
    }
  
    try {
      const response = await fetch('http://localhost:8000/api/token/refresh/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ refresh: refreshToken }),
      });
  
      const data = await response.json();
      
      if (response.ok && data.access) {
        localStorage.setItem('token', data.access);  // Sauvegarder le nouveau jeton d'accès
        return data.access;
      } else {
        console.error("Erreur lors du rafraîchissement du jeton:", data);
        return null;
      }
    } catch (error) {
      console.error("Erreur réseau:", error);
      return null;
    }
  };
  
  // Fonction pour vérifier si le jeton d'accès est encore valide
  export const isTokenExpired = (token) => {
    const decoded = JSON.parse(atob(token.split('.')[1])); // Décoder le payload du JWT
    const currentTime = Math.floor(Date.now() / 1000);  // Temps actuel en secondes
    return decoded.exp < currentTime;
  };
  
  // Fonction pour obtenir le jeton d'accès (si nécessaire, rafraîchissez-le)
  export const getAccessToken = async () => {
    const token = localStorage.getItem('token');  // Récupérer le jeton d'accès
    
    if (!token || isTokenExpired(token)) {
      const newToken = await getNewAccessToken();
      if (newToken) {
        return newToken;  // Retourner le nouveau jeton d'accès
      } else {
        console.error("Le jeton d'accès est expiré et le renouvellement a échoué.");
        window.location.href = '/login';  // Rediriger vers la page de connexion
      }
    }
  
    return token;  // Retourner le jeton d'accès existant
  };
  