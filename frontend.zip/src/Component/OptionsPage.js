import React from 'react';
import { MDBContainer, MDBRow, MDBCol, MDBBtn, MDBIcon, MDBCard, MDBCardBody } from 'mdb-react-ui-kit';

function OptionsPage() {
  // Vérifier si l'utilisateur est connecté avec un token
  const token = localStorage.getItem('token');
  
  if (!token) {
    window.location.href = '/login'; // Rediriger vers la page de login si l'utilisateur n'est pas connecté
  }

  return (
    <MDBContainer fluid className="p-3 my-5">
      <MDBRow className="justify-content-center">
        <MDBCol size="12" md="8" lg="6">
          <MDBCard className="shadow-lg rounded">
            <MDBCardBody>
              <div className="text-center">
                <h2 className="mb-4" style={{ color: '#4CAF50', fontWeight: 'bold' }}>
                  Welcome to Your Dashboard
                </h2>
                <p className="text-muted mb-4">Choose an option to proceed:</p>
              </div>

              <MDBRow className="g-4">
                <MDBCol size="12">
                  <MDBBtn
                    color="primary"
                    size="lg"
                    className="w-100 d-flex align-items-center justify-content-center"
                    onClick={() => window.location.href = '/profile'}
                  >
                    <MDBIcon fas icon="user" className="me-2" />
                    View Profile
                  </MDBBtn>
                </MDBCol>

                <MDBCol size="12">
                  <MDBBtn
                    color="success"
                    size="lg"
                    className="w-100 d-flex align-items-center justify-content-center"
                    onClick={() => window.location.href = '/chatbot'}
                  >
                    <MDBIcon fas icon="robot" className="me-2" />
                    Use Chatbot
                  </MDBBtn>
                </MDBCol>

                <MDBCol size="12">
                  <MDBBtn
                    color="info"
                    size="lg"
                    className="w-100 d-flex align-items-center justify-content-center"
                    onClick={() => window.location.href = '/disease-prediction'}
                  >
                    <MDBIcon fas icon="stethoscope" className="me-2" />
                    Disease Prediction
                  </MDBBtn>
                </MDBCol>
              </MDBRow>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
}

export default OptionsPage;
