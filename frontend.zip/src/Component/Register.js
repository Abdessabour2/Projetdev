import React, { useState } from 'react';
import { MDBContainer, MDBCol, MDBRow, MDBBtn, MDBInput } from 'mdb-react-ui-kit';

function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [address, setAddress] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault(); // Empêche la page de se recharger

    const userData = {
      username,
      email,
      password,
      phone_number: phoneNumber,
      address,
    };

    try {
      const response = await fetch('http://localhost:8000/api/register/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      const data = await response.json();

      if (response.ok) {
        setSuccess('Registration successful! Please login.');
        setError('');
        setUsername('');
        setEmail('');
        setPassword('');
        setPhoneNumber('');
        setAddress('');
      } else {
        setError(data.message || 'Registration failed. Please try again.');
        setSuccess('');
      }
    } catch (err) {
      setError('Something went wrong. Please try again later.');
      setSuccess('');
    }
  };

  return (
    <MDBContainer fluid className="p-3 my-5 h-custom">
      <MDBRow>
        <MDBCol col='10' md='6'>
          <img src="" alt="" className="img-fluid centered-image" />
        </MDBCol>

        <MDBCol col='4' md='6'>
          <form onSubmit={handleSubmit}>
            <MDBInput
              wrapperClass='mb-4'
              label='Username'
              id='formControlLg'
              type='text'
              size="lg"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <MDBInput
              wrapperClass='mb-4'
              label='Email address'
              id='formControlLg'
              type='email'
              size="lg"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <MDBInput
              wrapperClass='mb-4'
              label='Password'
              id='formControlLg'
              type='password'
              size="lg"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <MDBInput
              wrapperClass='mb-4'
              label='Phone Number'
              id='formControlLg'
              type='text'
              size="lg"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
            />
            <MDBInput
              wrapperClass='mb-4'
              label='Address'
              id='formControlLg'
              type='text'
              size="lg"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
            />

            {error && (
              <div className="alert alert-danger" role="alert">
                {error}
              </div>
            )}

            {success && (
              <div className="alert alert-success" role="alert">
                {success}
              </div>
            )}

            <div className='text-center text-md-start mt-4 pt-2'>
              <MDBBtn className="mb-0 px-5" size='lg' type="submit">
                Register
              </MDBBtn>
              <p className="small fw-bold mt-2 pt-1 mb-2">
                Already have an account? <a href="Login" className="link-danger">Login</a>
              </p>
            </div>
          </form>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
}

export default Register;
