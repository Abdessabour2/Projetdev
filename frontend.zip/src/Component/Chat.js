import React, { useState } from "react";
import axios from "axios";
import "./Chat.css"; // Assurez-vous d'avoir ajouté les styles ci-dessous

const Chat = () => {
  const [messages, setMessages] = useState([]);
  const [userMessage, setUserMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (userMessage.trim() === "") return;

    const message = {
      message: userMessage,
    };

    // Ajouter le message de l'utilisateur
    setMessages((prevMessages) => [
      ...prevMessages,
      { sender: "user", text: userMessage },
    ]);

    setUserMessage("");
    setLoading(true);

    try {
      const response = await axios.post(
        "http://127.0.0.1:8000/apichat/chat/",
        message,
        {
          headers: { "Content-Type": "application/json" },
        }
      );

      const botResponse = response.data.response;

      // Ajouter la réponse du bot
      setMessages((prevMessages) => [
        ...prevMessages,
        { sender: "bot", text: botResponse },
      ]);

      setLoading(false);
    } catch (error) {
      console.error("Erreur lors de l'envoi du message :", error);
      setMessages((prevMessages) => [
        ...prevMessages,
        { sender: "bot", text: "Une erreur s'est produite, veuillez réessayer." },
      ]);
      setLoading(false);
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === "Enter") {
      sendMessage();
    }
  };

  return (
    <div className="chat-container">
      <div className="chat-window">
        <div className="chat-header">
          <h2>Assistant Médical</h2>
        </div>
        <div className="messages">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`message ${msg.sender === "bot" ? "bot" : "user"}`}
            >
              {msg.sender === "bot" ? (
                <span className="avatar bot-avatar">🤖</span>
              ) : (
                <span className="avatar user-avatar">👤</span>
              )}
              <div className="message-text">{msg.text}</div>
            </div>
          ))}
          {loading && (
            <div className="message bot">
              <span className="avatar bot-avatar">🤖</span>
              <div className="message-text">Le bot écrit...</div>
            </div>
          )}
        </div>
        <div className="input-container">
          <input
            type="text"
            value={userMessage}
            onChange={(e) => setUserMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Posez une question médicale..."
          />
          <button onClick={sendMessage}>Envoyer</button>
        </div>
      </div>
    </div>
  );
};

export default Chat;
