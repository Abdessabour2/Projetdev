import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AppHeader from './Component/Header';
import AppHero from './Component/Hero';
import AppAbout from './Component/About';
// import AppTeam from './Component/Team';
import AppContact from './Component/contact';
import AppFooter from './Component/footer';
import Login from './Component/Login';
import Register from './Component/Register';
import './App.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import OptionsPage from './Component/OptionsPage';
import ProfilePage from './Component/ProfilePage'; 
import ChatbotPage from './Component/Chat';
import Prediction from './Component/Prediction';

function App() {
  return (
    <Router>
      <div className="App">
        <header id="header">
          <AppHeader />
        </header>  
        <main>
          <Routes>
            <Route path="/" element={
              <>
                
                <AppHero />
                <AppAbout />
                <AppHero />
                <AppAbout />
                <AppContact />
              </>
            } />
            <Route path="/about" element={
              <>
              <AppHero />
              <AppAbout />
              <AppHero />
              </>
              
          } /> 
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/options" element={<OptionsPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/services" element={<OptionsPage />} />
            <Route path="/chatbot" element={<ChatbotPage />} />
            <Route path="/disease-prediction" element={<Prediction />} />

            <Route exact path="/" component={AppAbout} /> 
          </Routes>
        </main>
        <AppFooter />
      </div>
    </Router>
  );
}

export default App;
