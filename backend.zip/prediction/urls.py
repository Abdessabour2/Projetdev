from django.urls import path
from .views import PredictView # Importez vos vues
from .views import render_react,render_prediction
urlpatterns = [
    
    # Route pour le point de prédiction
    
   
    # Route pour afficher le frontend
    
]
