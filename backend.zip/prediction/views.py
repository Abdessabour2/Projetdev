
from django.http import JsonResponse
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array
from PIL import Image
import numpy as np
import logging
from rest_framework.permissions import AllowAny
logger = logging.getLogger(__name__)
class PredictView(APIView):
    permission_classes = [AllowAny]
    parser_classes = (MultiPartParser, FormParser)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Charger le modèle enregistré
        self.model = tf.keras.models.load_model('model.h5')

    def get_class_info(self, class_ind):
        """Renvoie une description basée sur l'indice de classe."""
        descriptions = {
            0: "Actinic keratosis, also known as solar keratosis or senile keratosis, is a pre-malignant lesion or in situ squamous cell carcinoma.",
            1: "Basal cell carcinoma is a type of skin cancer that often appears as a slightly transparent bump on sun-exposed areas like the head and neck.",
            2: "Benign lichenoid keratosis (BLK) usually presents as a solitary lesion and may be associated with regressing solar lentigo.",
            3: "Dermatofibromas are small, noncancerous skin growths that often appear on the lower legs, upper arms, or upper back.",
            4: "A melanocytic nevus (commonly called a mole) is a type of melanocytic tumor that contains nevus cells.",
            5: "Pyogenic granulomas are small, round skin growths that are usually bloody red and tend to bleed due to a large number of blood vessels.",
            6: "Melanoma, the most serious type of skin cancer, develops in melanocytes, the cells that produce melanin. UV exposure increases the risk."
        }
        return descriptions.get(class_ind, "No information available for this class.")

    def post(self, request):
        try:
            logger.info("Requête POST reçue.") 
            # Récupérer l'image envoyée par l'utilisateur
            image_file = request.FILES['image']

            # Charger l'image avec PIL
            image = Image.open(image_file).convert('RGB') # Convertir en RGB
            # image = image.resize((28, 28))  # Redimensionner à (28, 28)
            image = image.resize((100, 75))
            # Convertir l'image en tableau numpy
            image_array = img_to_array(image) / 255.0  # Normaliser les pixels entre 0 et 1
            image_array = np.expand_dims(image_array, axis=0)  # Ajouter une dimension pour correspondre à l'entrée du modèle

            # Effectuer la prédiction
            prediction = self.model.predict(image_array)
            print(prediction)
            class_ind = np.argmax(prediction, axis=1)[0]  # Classe prédite

            # Obtenir les informations sur la classe
            info = self.get_class_info(class_ind)

            # Retourner la prédiction et les informations
            return JsonResponse({'prediction': int(class_ind), 'info': info})
        except Exception as e:
            logger.error(f"Erreur lors de la prédiction : {str(e)}")
            return JsonResponse({'error': str(e)}, status=400)
