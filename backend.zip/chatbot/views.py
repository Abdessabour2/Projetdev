from django.shortcuts import render
import requests
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt
def chatbot_response(request):
    if request.method == "POST":
        try:
            # Lire la requête utilisateur
            user_message = json.loads(request.body).get("message")

            # URL de l'API Rasa
            rasa_url = "http://localhost:5005/webhooks/rest/webhook"

            # Envoyer la requête à Rasa
            response = requests.post(rasa_url, json={"sender": "user", "message": user_message})

            # Récupérer la réponse
            rasa_response = response.json()

            # Extraire le message de Rasa
            bot_response = rasa_response[0].get("text") if rasa_response else "Je n'ai pas compris votre question."

            # Retourner la réponse sous forme de JSON
            return JsonResponse({"response": bot_response}, status=200)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)
    else:
        return JsonResponse({"error": "Invalid request method. Use POST."}, status=400)

# from django.http import JsonResponse
# from django.views.decorators.csrf import csrf_exempt
# import json

# @csrf_exempt
# def chatbot_response(request):
#     if request.method == "POST":
#         try:
#             data = json.loads(request.body)
#             user_message = data.get("message", "")

#             # Exemple de réponse du chatbot
#             if user_message.lower() in ["hi", "bonjour", "salut"]:
#                 bot_reply = "Bonjour ! Comment puis-je vous aider ?"
#             else:
#                 bot_reply = "Je n'ai pas compris. Pouvez-vous reformuler ?"

#             return JsonResponse({"response": bot_reply}, status=200)
#         except Exception as e:
#             return JsonResponse({"error": "Une erreur est survenue."}, status=500)
#     return JsonResponse({"error": "Méthode non autorisée."}, status=405)
