from django.contrib.auth import authenticate
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from users.models import CustomUser
from .serializers import UserSerializer, LoginSerializer,ProfileSerializer


class RegisterView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):

        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return Response({
                'message': 'User registered successfully.',
                'user': serializer.data
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        username = request.data.get("username")
        password = request.data.get("password")


        user = authenticate(username=username, password=password)

        if user is not None:

            refresh = RefreshToken.for_user(user)
            access_token = refresh.access_token
            return Response({
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }, status=status.HTTP_200_OK)
        
        return Response({'message': 'Invalid credentials.'}, status=status.HTTP_400_BAD_REQUEST)


class UserDetailView(APIView):
    def get(self, request, *args, **kwargs):
        user = request.user
        return Response({
            'username': user.username,
            'email': user.email,
            'phone_number': user.phone_number,
            'address': user.address
        }, status=status.HTTP_200_OK)
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import get_user_model
from rest_framework.parsers import MultiPartParser, FormParser
class ProfileView(APIView):
    
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser]

    def get(self, request, *args, **kwargs):
        print("Reçu : ", request.headers)  # En-têtes reçus
        print("Utilisateur : ", request.user)
        user = request.user
        data = {
    "username": user.username,
    "email": user.email,
    "phone_number": user.phone_number or "Not provided",
    "address": user.address or "Not provided",
    "profile_picture": user.profile_picture.url if user.profile_picture else None,
}
        print(data)
        return Response(data)
    def put(self, request, *args, **kwargs):
        user = request.user
        user.username = request.data.get('username', user.username)
        user.email = request.data.get('email', user.email)
        user.phone_number = request.data.get('phone_number', user.phone_number)
        user.address = request.data.get('address', user.address)


        if user.profile_picture:
            user.profile_picture = request.data.get('profile_picture',user.profile_picture)

        user.save()
        return Response({
            "username": user.username,
            "email": user.email,
            "phone_number": user.phone_number,
            "address": user.address,
            "profile_picture": user.profile_picture.url if user.profile_picture else None,
        })
    


from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import AllowAny
from rest_framework import status

class AboutUsView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, *args, **kwargs):
        team_data = [
            {
                "id": 1,
                "image": "/static/images/houdayfa.png",
                "linkedLink": "https://www.linkedin.com/in/houdayfa-housny-794a58285/",
                "githubLink": "https://github.com/Houdayfahousny",
                "fbLink": "https://www.facebook.com/profile.php?id=100008389418691",
                "name": "Houdayfa HOUSNY",
                "designation": "Frontend Cell",
                
            },
            {
                "id": 2,
                "image": "/static/images/abdessabour.png",
                "linkedLink": "https://www.linkedin.com/in/abdessabour-ahzab-9734082a5/",
                "githubLink": "https://github.com/Abdessabour2",
                "fbLink": "https://www.facebook.com/abdessabour.ahzab.39",
                "name": "Abdessabour AHZAB",
                "designation": "Frontend & Backend & Model & Chatbot Cell",
            },
            {
                "id": 3,
                "image": "/static/images/ramzi.png",
                "linkedLink": "",
                "githubLink": "",
                "fbLink": "",
                "name": "Youssef RAMZI",
                "designation": "Data Cell",
            }
        ]
        return Response(team_data, status=status.HTTP_200_OK)
