from django.test import TestCase
# users/tests.py

from django.test import TestCase
from django.urls import reverse
from rest_framework import status
from django.contrib.auth import get_user_model

class UserRegistrationTestCase(TestCase):
    def test_register_user(self):
        url = reverse('register')  

        data = {
            'username': 'newuser',
            'password': 'password123',
            'email': 'newuser@example.com'
        }

        response = self.client.post(url, data, format='json')

        # Vérifiez que l'utilisateur a été créé et que la réponse est correcte
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(get_user_model().objects.count(), 1)  # Vérifier qu'un utilisateur a été ajouté

        # Vérifier que les informations de l'utilisateur sont bien dans la base de données
        user = get_user_model().objects.get(username='newuser')
        self.assertEqual(user.email, 'newuser@example.com')
        self.assertTrue(user.check_password('password123'))  # Vérifier que le mot de passe est correct
# users/tests.py
from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework import status
from rest_framework.test import APIClient

class UserLoginTestCase(TestCase):
    def setUp(self):
        # Crée un utilisateur pour les tests
        self.user = get_user_model().objects.create_user(
            username="testuser", 
            password="testpassword"
        )
        self.client = APIClient()

    def test_login_user(self):

        response = self.client.post('/api/login/', {
            'username': 'testuser',
            'password': 'testpassword'
        }, format='json')
        

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)
        self.assertIn('refresh', response.data)

    def test_login_invalid_user(self):
        response = self.client.post('/api/login/', {
            'username': 'invaliduser',
            'password': 'wrongpassword'
        }, format='json')
        

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('message', response.data)
from rest_framework.test import APITestCase
from rest_framework import status
from django.contrib.auth import get_user_model
from rest_framework.authtoken.models import Token

User = get_user_model()

class ProfileAPITestCase(APITestCase):
    def setUp(self):

        self.user = User.objects.create_user(
            username="testuser",
            email="testuser@example.com",
            password="testpassword",
            phone_number="123456789",  
            address="123 Test St"
        )
 
        self.token = Token.objects.create(user=self.user)
        self.api_authentication()

    def api_authentication(self):
        self.client.credentials(HTTP_AUTHORIZATION='Token ' + self.token.key)

    def test_profile_authenticated(self):
        # Tester que l'utilisateur authentifié peut accéder à l'API
        response = self.client.get('/api/profile/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['username'], self.user.username)
        self.assertEqual(response.data['email'], self.user.email)
        self.assertEqual(response.data['phone_number'], self.user.phone_number)
        self.assertEqual(response.data['address'], self.user.address)

    def test_profile_unauthenticated(self):
        # Tester que l'accès non authentifié est interdit
        self.client.force_authenticate(user=None)  # Supprimer l'authentification
        response = self.client.get('/api/profile/')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
import requests

# URL de l'API pour mettre à jour le profil
url = "http://localhost:8000/api/profile/"

# Jeton d'authentification (remplacez-le par votre jeton actuel)
token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNzMyODI3Njc2LCJpYXQiOjE3MzI4MjczNzYsImp0aSI6IjEzNTIwYjA0NTJhYjRhMzU4YjUyOTRlZDc2ZmRjYWM5IiwidXNlcl9pZCI6MX0.kzgFrg6Z6JwdNR6wUqS3NbZLuI41WHd2LD1bHe-rHDs"

# Chemin vers l'image à envoyer
image_path = "users\images\img1.png"

# Données du formulaire à envoyer avec l'image
form_data = {
    "username": "root",
    "email": "root@gamil.com",
    "phone_number": "123456789",
    "address": "New Address",
}


with open(image_path, "rb") as image_file:
    files = {
        "profile_picture": image_file, 
    }


    headers = {
        "Authorization": f"Bearer {token}",
    }


    response = requests.put(url, data=form_data, files=files, headers=headers)


    if response.status_code == 200:
        print("Mise à jour réussie :", response.json())
    else:
        print("Erreur :", response.status_code, response.text)
