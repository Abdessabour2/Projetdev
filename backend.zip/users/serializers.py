from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import CustomUser


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = get_user_model()
        fields = ['username', 'email', 'password', 'phone_number', 'address']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = get_user_model().objects.create_user(**validated_data)
        return user
class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'phone_number', 'address', 'profile_picture']

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()
# from rest_framework import serializers
# from .models import AboutUs

# class AboutUsSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = AboutUs
#         fields = ['title', 'subtitle', 'description', 'image_url']
